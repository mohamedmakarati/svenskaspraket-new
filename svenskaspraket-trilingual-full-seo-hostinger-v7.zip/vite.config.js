import { defineConfig } from 'vite';
import { resolve } from 'node:path';

export default defineConfig({
  build: {
    outDir: 'dist',
    rollupOptions: {
      input: {
        home: resolve(import.meta.dirname, 'index.html'),
        englishHome: resolve(import.meta.dirname, 'en/index.html'),
        arabicHome: resolve(import.meta.dirname, 'ar/index.html'),
        lessons: resolve(import.meta.dirname, 'lessons.html'),
        verbs: resolve(import.meta.dirname, 'verbs.html'),
        verbsA2: resolve(import.meta.dirname, 'verbs-a2.html'),
        verbsB1B2: resolve(import.meta.dirname, 'verbs-b1b2.html'),
        vocabulary: resolve(import.meta.dirname, 'vocabulary.html'),
        notFound: resolve(import.meta.dirname, '404.html'),
      },
    },
  },
});
