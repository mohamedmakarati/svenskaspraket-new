# SvenskaSpråket

Responsive Swedish-learning website with Swedish–Arabic word practice, learning modules, level selection, and SEO metadata.

The A1 verb library contains 131 verbs with full conjugation, English and Arabic meanings, group filters, search, auxiliary verbs, and an interactive quiz.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL shown by Vite.

## Build

```bash
npm run build
```

The production website is generated in `dist/`.

## Publish

Upload the contents of `dist/` to `public_html` in Hostinger or any static web host.
