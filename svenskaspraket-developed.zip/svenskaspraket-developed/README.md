# SvenskaSpråket

Responsive Swedish-learning website with Swedish–Arabic word practice, learning modules, level selection, and SEO metadata.

## Run locally

Open `index.html` in a browser. No installation is required.

## Publish

Upload the contents of this folder to `public_html` in Hostinger or any static web host.
